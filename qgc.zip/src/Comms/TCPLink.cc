/****************************************************************************
 *
 * (c) 2009-2024 QGROUNDCONTROL PROJECT <http://www.qgroundcontrol.org>
 *
 * QGroundControl is licensed according to the terms in the file
 * COPYING.md in the root of the source code directory.
 *
 ****************************************************************************/

#include "TCPLink.h"
#include "DeviceInfo.h"
#include "QGCLoggingCategory.h"

#include <QtCore/QThread>
#include <QtCore/QTimer>
#include <QtNetwork/QHostInfo>
#include <QtNetwork/QTcpSocket>

QGC_LOGGING_CATEGORY(TCPLinkLog, "test.comms.tcplink")

namespace {
    constexpr int CONNECT_TIMEOUT_MS = 5000;
    constexpr int TYPE_OF_SERVICE = 32; // Set ToS to priority for low delay
}

/*===========================================================================*/

TCPConfiguration::TCPConfiguration(const QString &name, QObject *parent)
    : LinkConfiguration(name, parent)
{
    qCDebug(TCPLinkLog) << this;
}

TCPConfiguration::TCPConfiguration(const TCPConfiguration *copy, QObject *parent)
    : LinkConfiguration(copy, parent)
    , _host(copy->host())
    , _port(copy->port())
{
    qCDebug(TCPLinkLog) << this;
}

TCPConfiguration::~TCPConfiguration()
{
    qCDebug(TCPLinkLog) << this;
}

void TCPConfiguration::setHost(const QString &host)
{
    const QString cleanHost = host.trimmed();
    if (cleanHost != _host) {
        _host = cleanHost;
        emit hostChanged();
    }
}

void TCPConfiguration::setPort(quint16 port)
{
    if (port != _port) {
        _port = port;
        emit portChanged();
    }
}

void TCPConfiguration::copyFrom(const LinkConfiguration *source)
{
    Q_ASSERT(source);
    LinkConfiguration::copyFrom(source);

    const TCPConfiguration* const tcpSource = qobject_cast<const TCPConfiguration*>(source);
    Q_ASSERT(tcpSource);

    setHost(tcpSource->host());
    setPort(tcpSource->port());
}

void TCPConfiguration::loadSettings(QSettings &settings, const QString &root)
{
    settings.beginGroup(root);

    setHost(settings.value(QStringLiteral("host"), host()).toString());
    setPort(static_cast<quint16>(settings.value(QStringLiteral("port"), port()).toUInt()));

    settings.endGroup();
}

void TCPConfiguration::saveSettings(QSettings &settings, const QString &root) const
{
    settings.beginGroup(root);

    settings.setValue(QStringLiteral("host"), host());
    settings.setValue(QStringLiteral("port"), port());

    settings.endGroup();
}

/*===========================================================================*/

TCPWorker::TCPWorker(const TCPConfiguration *config, QObject *parent)
    : QObject(parent)
    , _config(config)
{
    qCDebug(TCPLinkLog) << this;
}

TCPWorker::~TCPWorker()
{
    disconnectFromHost();

    qCDebug(TCPLinkLog) << this;
}

bool TCPWorker::isConnected() const
{
    return (_socket && _socket->isOpen() && (_socket->state() == QAbstractSocket::ConnectedState));
}

void TCPWorker::setupSocket()
{
    Q_ASSERT(!_socket);
    _socket = new QTcpSocket(this);

    _socket->setSocketOption(QAbstractSocket::LowDelayOption, 1);
    _socket->setSocketOption(QAbstractSocket::KeepAliveOption, 1);
    _socket->setSocketOption(QAbstractSocket::TypeOfServiceOption, TYPE_OF_SERVICE);

    Q_ASSERT(!_connectionTimer);
    _connectionTimer = new QTimer(this);
    _connectionTimer->setSingleShot(true);

    (void) connect(_socket, &QTcpSocket::connected, this, &TCPWorker::_onSocketConnected);
    (void) connect(_socket, &QTcpSocket::disconnected, this, &TCPWorker::_onSocketDisconnected);
    (void) connect(_socket, &QTcpSocket::readyRead, this, &TCPWorker::_onSocketReadyRead);
    (void) connect(_socket, &QTcpSocket::errorOccurred, this, &TCPWorker::_onSocketErrorOccurred);
    (void) connect(_connectionTimer, &QTimer::timeout, this, &TCPWorker::_onConnectionTimeout);

    if (TCPLinkLog().isDebugEnabled()) {
        // (void) connect(_socket, &QTcpSocket::bytesWritten, this, &TCPWorker::_onSocketBytesWritten);

        (void) connect(_socket, &QTcpSocket::stateChanged, this, [](QTcpSocket::SocketState state) {
            qCDebug(TCPLinkLog) << "TCP State Changed:" << state;
        });

        (void) connect(_socket, &QTcpSocket::hostFound, this, [this]() {
            qCDebug(TCPLinkLog) << "TCP Host Found" << _socket->peerName() << _socket->peerAddress() << _socket->peerPort();
        });
    }
}

void TCPWorker::connectToHost()
{
    if (isConnected()) {
        qCWarning(TCPLinkLog) << "Already connected to" << _config->host() << ":" << _config->port();
        return;
    }

    if (_config->host().isEmpty()) {
        if (!_errorEmitted.exchange(true)) {
            emit errorOccurred(tr("Connection Failed: Host address is empty"));
        }
        return;
    }

    _errorEmitted = false;

    qCDebug(TCPLinkLog) << "Attempting to connect to host:" << _config->host() << "port:" << _config->port();

    // Start connection timer
    _connectionTimer->start(CONNECT_TIMEOUT_MS);

    // connectToHost handles both IP addresses and hostnames with async DNS resolution
    _socket->connectToHost(_config->host(), _config->port());
}

void TCPWorker::disconnectFromHost()
{
    _connectionTimer->stop();

    if (!isConnected()) {
        qCDebug(TCPLinkLog) << "Already disconnected from host:" << _config->host() << "port:" << _config->port();
        return;
    }

    qCDebug(TCPLinkLog) << "Attempting to disconnect from host:" << _config->host() << "port:" << _config->port();

    _socket->disconnectFromHost();
}

void TCPWorker::writeData(const QByteArray &data)
{
    if (data.isEmpty()) {
        emit errorOccurred(tr("Data to Send is Empty"));
        return;
    }

    if (!isConnected()) {
        emit errorOccurred(tr("Socket is not connected"));
        return;
    }

    qint64 totalBytesWritten = 0;
    while (totalBytesWritten < data.size()) {
        const qint64 bytesWritten = _socket->write(data.constData() + totalBytesWritten, data.size() - totalBytesWritten);
        if (bytesWritten == -1) {
            emit errorOccurred(tr("Could Not Send Data - Write Failed: %1").arg(_socket->errorString()));
            return;
        } else if (bytesWritten == 0) {
            emit errorOccurred(tr("Could Not Send Data - Write Returned 0 Bytes"));
            return;
        }
        totalBytesWritten += bytesWritten;
    }

    emit dataSent(data.first(totalBytesWritten));
}

void TCPWorker::_onSocketConnected()
{
    _connectionTimer->stop();
    qCDebug(TCPLinkLog) << "Socket connected:" << _config->host() << _config->port();
    _errorEmitted = false;
    emit connected();
}

void TCPWorker::_onSocketDisconnected()
{
    _connectionTimer->stop();
    qCDebug(TCPLinkLog) << "Socket disconnected:" << _config->host() << _config->port();
    _errorEmitted = false;
    emit disconnected();
}

void TCPWorker::_onSocketReadyRead()
{
    const QByteArray data = _socket->readAll();
    if (!data.isEmpty()) {
        emit dataReceived(data);
    }
}

void TCPWorker::_onSocketBytesWritten(qint64 bytes)
{
    qCDebug(TCPLinkLog) << _config->host() << "Wrote" << bytes << "bytes";
}

void TCPWorker::_onSocketErrorOccurred(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError);

    // Stop timer on error
    _connectionTimer->stop();

    const QString errorString = _socket->errorString();
    qCWarning(TCPLinkLog) << "Socket error:" << socketError << errorString;

    if (!_errorEmitted.exchange(true)) {
        // Provide more helpful error messages for common issues
        QString enhancedError = errorString;
        if (socketError == QAbstractSocket::HostNotFoundError) {
            enhancedError = tr("Host '%1' not found. Please check the hostname.").arg(_config->host());
        } else if (socketError == QAbstractSocket::ConnectionRefusedError) {
            enhancedError = tr("Connection refused by %1:%2. Is the server running?").arg(_config->host()).arg(_config->port());
        } else if (socketError == QAbstractSocket::NetworkError) {
            enhancedError = tr("Network error connecting to %1:%2").arg(_config->host()).arg(_config->port());
        }
        emit errorOccurred(enhancedError);
    }
}

void TCPWorker::_onConnectionTimeout()
{
    if (!isConnected() && _socket->state() == QAbstractSocket::ConnectingState) {
        qCWarning(TCPLinkLog) << "Connection timeout to" << _config->host() << ":" << _config->port();

        _socket->abort();

        if (!_errorEmitted.exchange(true)) {
            emit errorOccurred(tr("Connection timeout: Could not connect to %1:%2 within %3 seconds")
                             .arg(_config->host())
                             .arg(_config->port())
                             .arg(CONNECT_TIMEOUT_MS / 1000));
        }

        _onSocketDisconnected();
    }
}

/*===========================================================================*/

TCPLink::TCPLink(SharedLinkConfigurationPtr &config, QObject *parent)
    : LinkInterface(config, parent)
    , _tcpConfig(qobject_cast<const TCPConfiguration*>(config.get()))
    , _worker(new TCPWorker(_tcpConfig))
    , _workerThread(new QThread(this))
{
    qCDebug(TCPLinkLog) << this;

    _workerThread->setObjectName(QStringLiteral("TCP_%1").arg(_tcpConfig->name()));

    _worker->moveToThread(_workerThread);

    (void) connect(_workerThread, &QThread::started, _worker, &TCPWorker::setupSocket);
    (void) connect(_workerThread, &QThread::finished, _worker, &QObject::deleteLater);

    (void) connect(_worker, &TCPWorker::connected, this, &TCPLink::_onConnected, Qt::QueuedConnection);
    (void) connect(_worker, &TCPWorker::disconnected, this, &TCPLink::_onDisconnected, Qt::QueuedConnection);
    (void) connect(_worker, &TCPWorker::errorOccurred, this, &TCPLink::_onErrorOccurred, Qt::QueuedConnection);
    (void) connect(_worker, &TCPWorker::dataReceived, this, &TCPLink::_onDataReceived, Qt::QueuedConnection);
    (void) connect(_worker, &TCPWorker::dataSent, this, &TCPLink::_onDataSent, Qt::QueuedConnection);

    _workerThread->start();
}

TCPLink::~TCPLink()
{
    TCPLink::disconnect();

    _workerThread->quit();
    if (!_workerThread->wait()) {
        qCWarning(TCPLinkLog) << "Failed to wait for TCP Thread to close";
    }

    qCDebug(TCPLinkLog) << this;
}

bool TCPLink::isConnected() const
{
    return _worker->isConnected();
}

bool TCPLink::_connect()
{
    return QMetaObject::invokeMethod(_worker, "connectToHost", Qt::QueuedConnection);
}

void TCPLink::disconnect()
{
    (void) QMetaObject::invokeMethod(_worker, "disconnectFromHost", Qt::QueuedConnection);
}

void TCPLink::_onConnected()
{
    emit connected();
}

void TCPLink::_onDisconnected()
{
    emit disconnected();
}

void TCPLink::_onErrorOccurred(const QString &errorString)
{
    qCWarning(TCPLinkLog) << "Communication error:" << errorString;
    emit communicationError(tr("TCP Link Error"), tr("Link %1: (Host: %2 Port: %3) %4").arg(_tcpConfig->name(), _tcpConfig->host()).arg(_tcpConfig->port()).arg(errorString));
}

void TCPLink::_onDataReceived(const QByteArray &data)
{
    emit bytesReceived(this, data);
}

void TCPLink::_onDataSent(const QByteArray &data)
{
    emit bytesSent(this, data);
}

void TCPLink::_writeBytes(const QByteArray& bytes)
{
    (void) QMetaObject::invokeMethod(_worker, "writeData", Qt::QueuedConnection, Q_ARG(QByteArray, bytes));
}

bool TCPLink::isSecureConnection() const
{
    return QGCDeviceInfo::isNetworkEthernet();
}
